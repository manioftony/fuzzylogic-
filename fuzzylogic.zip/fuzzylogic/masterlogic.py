import pandas as pd
import sys
from common import stringcoverage, convert_format, percent_difference_calculator, set_list
from common import set_list, calculate_data


class Base:
    def __init__(self, file1, file2, f1_columns, f2_columns, percentage):
        self.file1 = file1
        self.file2 = file2
        self.f1_columns = f1_columns
        self.f2_columns = f2_columns
        self.percentage = percentage

    def verify_files(self, name):
        try:
            obj = pd.read_excel(name)
            return True
        except FileNotFoundError as e:
            print(f"File {name} not found!", file=sys.stderr)
            return False

    def file_check(self, filename1, filename2):
        obj = self.verify_files(filename1)
        obj1 = self.verify_files(filename2)
        if obj and obj1:
            return True
        else:
            return False

    def read_data_from(self, name1, name2):
        obj = pd.read_excel(name1)
        obj2 = pd.read_excel(name2)
        return obj, obj2

    def validate_columns(self):
        filename1 = self.file1
        filename2 = self.file2
        f1_columns = self.f1_columns
        f2_columns = self.f2_columns
        obj = self.file_check(filename1, filename2)
        if obj:
            obj1, obj2 = self.read_data_from(filename1, filename2)
            a_obj = [True for i in f1_columns if i in obj1.columns]
            b_obj = [True for i in f2_columns if i in obj1.columns]
            if all(a_obj) and all(b_obj):
                # import ipdb; ipdb.set_trace()
                self.parse_data(obj1, obj2, f1_columns, f2_columns)
            return obj1, obj2


    def parse_data(self, data1, data2, f1_columns, f2_columns):
        # import ipdb; ipdb.set_trace()
        aa = data1
        bb = data2
        for k in range(len(f1_columns)):
            total = []
            a_obj = aa[f1_columns]
            b_obj = bb[f2_columns]
            obj1 = a_obj.values.tolist()
            obj2 = b_obj.values.tolist()
            for i in obj1:
                for j in obj2:
                    if calculate_data(i[k], j[k], percentage[k]):
                        total.append([i[k], j[k]])
            if total:
                name1, name2 = f1_columns[k], f2_columns[k]
                obj = pd.DataFrame(set_list(total))
                obj.columns = (name1, name2)
                sublist = set_list(total)
                # import ipdb;ipdb.set_trace()
                if name1 == name2:
                    aa = aa[aa[name1].isin(obj[name1].iloc[:, 0])]
                    bb = bb[bb[name2].isin(obj[name2].iloc[:, 1])]
                else:
                    aa = aa[aa[name1].isin(obj[name1].iloc[:, 0])]
                    bb = bb[bb[name2].isin(obj[name2].iloc[:, 1])]

        print ("=====file1======/n;",aa)
        print ("=====file2======/n",bb)
        aa.to_csv("output1.csv")
        bb.to_csv("output2.csv")
        print ("Successfully Done")



file1 = "Book1.xlsx"
file2 = "Book2.xlsx"
f1_columns = ["First Name", "Last Name", "value", "date"]
f2_columns = ["First Name", "Last Name", "value", "date"]
# f1_columns = ["First Name","Last Name","value"]
# f2_columns = ["First Name","Last Name","value"]
# percentage = [86, 20, 25, 100]
# percentage = [70, 50, 100,100]
percentage = [100,100,5,100]
f1_dateformat = 'yyyy-mm-dd'
f2_dateformat = 'mm/dd/yyyy'
p1 = Base(file1, file2, f1_columns, f2_columns, percentage)
p1.validate_columns()
