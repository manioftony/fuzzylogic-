import datetime
import difflib
from fuzzywuzzy import fuzz


def compare(a, b):
    seq = difflib.SequenceMatcher(None, a, b)
    d = seq.ratio() * 100
    return d


def percent_difference_calculator(v1, v2):
    # https: // www.calculatorsoup.com / calculators / algebra / percent - difference - calculator.php
    return abs((v1 - v2) / ((v1 + v2) / 2) * 100)


def convert_format(date, date_format):
    try:
        date = str(date).split(" ")[0]
    except:
        pass
    all_format = ['-', '/', '.']
    for i in all_format:
        if i in date_format:
            simple = i
    format_date = ''
    for jj in date_format.split(simple):
        if 'y' in jj:
            format_date += "%" + jj[0].upper() + simple
        else:
            format_date += "%" + jj[0].lower() + simple
    org_date = format_date[:-1]
    try:
        obj = datetime.datetime.strptime(date, org_date)
    except:
        return None
    return obj.date()


def checkstring(haystack, needle):
    haystack, needle = haystack.lower(), needle.lower()
    if len(needle) == 0:
        return 0
    for i in range(len(haystack)):
        if haystack[i:i + len(needle)] == needle:
            return i
    return -1


def stringcoverage(s1, s2):
    if len(s1) == 1 or len(s2) == 1:
        if len(s1) == 1 and len(s2) == 1:
            return compare(s1, s2)
        else:
            if len(s1) > 1:
                s1, s2 = s2, s1
                if checkstring(s2, s1) < 0:
                    return 0
                else:
                    return 100 / len(s2)
            else:
                if checkstring(s2, s1) < 0:
                    return 0
                else:
                    return 100 / len(s2)
    elif len(s1) == len(s2):
        if checkstring(s1, s2) < 0:
            return 0
        else:
            return compare(s1, s2)
    else:
        if checkstring(s1, s2) == -1:
            return 0
        else:
            return fuzz.WRatio(s1, s2)
            # return checkstring(s1, s2)


def combine_list(sublist):
    total = []
    for i in sublist:
        for j in i:
            total.append(j)
    return list(set(total))


def set_list(k):
    total = []
    for elem in k:
        if elem not in total:
            total.append(elem)
    return total


def calculate_data(value1, value2, accuracy):
    if str(value1)=='nan' or str(value2)=='nan':
        return False
    else:
        f1_dateformat = 'yyyy-mm-dd'
        f2_dateformat = 'yyyy-mm-dd'
        if type(value1) == str and type(value2) == str:
            if stringcoverage(value1, value2) >= accuracy:
                return True
            else:
                return False
        elif type(value1) == int and type(value2) == int:

            if value1 == value2:
                return True
            else:
                return percent_difference_calculator(value1, value2) <= accuracy
        elif type(value1) == float and type(value2) == float:

            if value1 == value2:
                return True
            else:
                # import ipdb; ipdb.set_trace()
                if int(value1) == int(value2):
                    return percent_difference_calculator(value1, value2) <= accuracy
                else:
                    # print (value1,value2,percent_difference_calculator(value1, value2)<=accuracy,accuracy)
                    return percent_difference_calculator(value1, value2) <= accuracy
        else:
            a = convert_format(value1, f1_dateformat)
            b = convert_format(value2, f2_dateformat)
            if a == b:
                return True
            else:
                return False
