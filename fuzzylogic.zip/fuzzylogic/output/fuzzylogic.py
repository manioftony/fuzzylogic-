import pandas as pd
import sys,os
from common import stringcoverage, convert_format, percent_difference_calculator, set_list
from common import set_list, calculate_data
import csv
import numpy as np

class Base:
    def __init__(self, file1, file2, f1_columns, f2_columns, percentage,output1, output2, f1_dateformat, f2_dateformat,f1_delimiter,f2_delimiter):
        self.file1 = file1
        self.file2 = file2
        self.f1_columns = f1_columns
        self.f2_columns = f2_columns
        self.percentage = percentage
        self.output1 = output1
        self.output2 = output2
        self.f1_dateformat = f1_dateformat
        self.f2_dateformat = f2_dateformat
        self.f1_delimiter = f1_delimiter
        self.f2_delimiter = f2_delimiter
    def checkfileextension(self,file,delimetr):
        filename, file_extension = os.path.splitext(file)
        if file_extension=='.txt':
            obj = self.txttodataframe(file,delimetr)
            return not obj.empty
        else:
            return False

    def txttodataframe(self, file ,delimiter):
        # import ipdb; ipdb.set_trace()
        filename, file_extension = os.path.splitext(file)
        if file_extension=='.txt':
            with open(file,'r') as script:
                speech = script.read().splitlines()
                obj = [row for row in csv.reader(speech,delimiter=eval(delimiter))]
                column = obj[0]
                data = obj[1:]
                dataframe = pd.DataFrame(data,columns=column)
                return dataframe



    def verify_files(self, name,delimetr=None):
        try:
            filename, file_extension = os.path.splitext(name)
            if file_extension=='.txt':
                obj = self.checkfileextension(name,delimetr)
                return obj
            elif file_extension=='.csv':
                obj = pd.read_csv(name)
                return True
            elif file_extension=='.xlsx':
                obj = pd.read_excel(name)
                return True
        except FileNotFoundError as e:
            print(f"File {name} not found!", file=sys.stderr)
            return False

    def file_check(self, filename1, filename2,f1_delimiter=None,f2_delimiter=None):
        obj = self.verify_files(filename1,f1_delimiter)
        obj1 = self.verify_files(filename2,f2_delimiter)
        if obj and obj1:
            return True
        else:
            return False

    def read_data_from(self, file,delimetr=None):
        filename, file_extension = os.path.splitext(file)
        if file_extension=='.txt':
            obj = self.txttodataframe(file,delimetr)
        elif file_extension=='.csv':
            obj = pd.read_csv(file)
        elif file_extension=='.xlsx':
            obj = pd.read_excel(file)
        return obj

    def validate_columns(self):
        filename1 = self.file1
        filename2 = self.file2
        f1_columns = self.f1_columns
        f2_columns = self.f2_columns
        f1_delimiter = self.f1_delimiter
        f2_delimiter = self.f2_delimiter
        obj = self.file_check(filename1, filename2,f1_delimiter,f2_dateformat)
        if obj:
            if f1_delimiter:
                obj1 = self.read_data_from(filename1,f1_delimiter)
            if f2_delimiter:
                obj2 = self.read_data_from(filename2,f2_delimiter)
            else:
                obj1 = self.read_data_from(filename1)
                obj2 = self.read_data_from(filename2)
            a_obj = [True for i in f1_columns if i in obj1.columns]
            b_obj = [True for i in f2_columns if i in obj2.columns]
            if all(a_obj) and all(b_obj):
                self.parse_data(obj1, obj2, f1_columns, f2_columns)
            return obj1, obj2


    def parse_data(self, data1, data2, f1_columns, f2_columns):
        output1 = self.output1
        output2 = self.output2
        aa = data1
        bb = data2
        for k in range(len(f1_columns)):
            total = []
            a_obj = aa[f1_columns]
            b_obj = bb[f2_columns]
            obj1 = a_obj.values.tolist()
            obj2 = b_obj.values.tolist()
            for i in obj1:
                for j in obj2:
                    if calculate_data(i[k], j[k], percentage[k]):
                        total.append([i[k], j[k]])
            if total:
                name1, name2 = f1_columns[k], f2_columns[k]
                obj = pd.DataFrame(set_list(total))
                obj.columns = (name1, name2)
                sublist = set_list(total)
                if name1 == name2:
                    aa = aa[aa[name1].isin(obj[name1].iloc[:, 0])]
                    bb = bb[bb[name2].isin(obj[name2].iloc[:, 1])]
                else:
                    aa = aa[aa[name1].isin(obj[name1].iloc[:, 0])]
                    bb = bb[bb[name2].isin(obj[name2].iloc[:, 1])]

        aa = aa.replace(np.nan, '')
        bb = bb.replace(np.nan, '')
        print ("=====file1======")
        print (aa)
        print ("=====file2======")
        print (bb)
        aa.to_csv(output1+"output1.csv")
        bb.to_csv(output1+"output2.csv")
        print ("Successfully Done")


import configparser
config = configparser.ConfigParser()
config.read('config.ini')



file1 = config['config']['file1']
file2 = config['config']['file2']
f1_columns = eval(config['config']['f1_columns'])
f2_columns = eval(config['config']['f1_columns'])
percentage = eval(config['config']['percentage'])
f1_dateformat = config['config']['f1_dateformat']
f2_dateformat = config['config']['f2_dateformat']
output1 = config['config']['output1']
output2 = config['config']['output2']
f1_delimiter = config['config']['f1_delimiter']
f2_delimiter = config['config']['f2_delimiter']


p1 = Base(file1, file2, f1_columns, f2_columns, percentage,output1,output2,f1_dateformat,f2_dateformat,f1_delimiter,f2_delimiter)
p1.validate_columns()


# file1 txt
# file2 excel
# file1 txt delimetr |
# file2 txt delimetr /
