import pandas as pd
import sys
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

# obj = pd.read_excel("sample_data.xlsx")

class Base:
    def __init__(self,name1,name2,parameters,accuracy):
        self.name1 = name1
        self.name2 = name2
        self.parameters = parameters
        self.accuracy = accuracy

    def verify_files(self, name):
        try:
           obj = pd.read_excel(name)
           return  True
        except FileNotFoundError as e:
            print(f"File {name} not found!", file=sys.stderr)
            return False

    def file_check(self,filename1,filename2):
        obj = self.verify_files(filename1)
        obj1 = self.verify_files(filename2)
        if obj and obj1:
            return True
        else:
            return False

    def read_data_from(self,name1,name2):
        obj = pd.read_excel(name1)
        obj2 = pd.read_excel(name2)
        return obj, obj2

    def validate_columns(self):
        filename1 = self.name1
        filename2 = self.name2
        parametes = self.parameters
        obj = self.file_check(filename1, filename2)
        if obj:
            obj1, obj2 = self.read_data_from(filename1,filename2)
            a_obj = [True for i in parametes if i in obj1.columns]
            b_obj = [True for i in parametes if i in obj1.columns]
            if all(a_obj)  and all(b_obj):
                self.parse_data(obj1,obj2,parametes)
                # import ipdb;ipdb.set_trace()
                # print(obj1,obj2)
            return obj1, obj2

    def calculate_data(self, obj1, obj2):
        accuracy = self.accuracy
        for i in range(len(obj1)):
            count_obj = fuzz.ratio(obj1[i], obj2[i])
            print (count_obj,accuracy)
            if count_obj == accuracy:
                return True
            else:
                return False





    def parse_data(self,data1,data2,parametes):
        a_obj = data1[parametes]
        b_obj = data2[parametes]
        obj1 = a_obj.values.tolist()
        obj2 = b_obj.values.tolist()
        total = []
        for i,j in enumerate(obj1):
            if self.calculate_data(obj1[i], obj2[i]):
                total.append(j)
        total_data = [parametes]+total
        # total_data.append(total)
        with open("output.txt", "a") as file:
            # file.write("\n")
            for i in total_data:
                string_data = ','. join(i)
                file.write(string_data+"\n")

file1 = "sample_data.xlsx"
file2 = "sample_data1.xlsx"
f1_columns = ["First Name","Last Name"]
f2_columns = ["First Name","Last Name"]
percentage = [70,45]
p1 = Base(file1)
# p1 = Base("sample_data.xlsx","sample_data1.xlsx" ,["First Name","Last Name"],86)
p1.validate_columns()


