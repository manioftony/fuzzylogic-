import pandas as pd
from common import set_list, calculate_data


file1 = "Book1.xlsx"
file2 = "Book2.xlsx"
f1_columns = ["First Name", "Last Name", "value", "date"]
f2_columns = ["First Name", "Last Name", "value", "date"]
# f1_columns = ["First Name", "Last Name"]
# f2_columns = ["First Name", "Last Name"]

percentage = [70, 50, 100,100]
obj1 = pd.read_excel(file1)
obj2 = pd.read_excel(file2)
a_obj = obj1[f1_columns]
b_obj = obj2[f2_columns]
aa = obj1
bb = obj2

obj1 = a_obj.values.tolist()
obj2 = b_obj.values.tolist()

for k in range(len(f1_columns)):
    total = []
    a_obj = aa[f1_columns]
    b_obj = bb[f2_columns]
    obj1 = a_obj.values.tolist()
    obj2 = b_obj.values.tolist()
    for i in obj1:
        for j in obj2:
            if calculate_data(j[k], i[k], percentage[k]):
                total.append([j[k], i[k]])
    if total:
        name1, name2 = f1_columns[k], f2_columns[k]
        obj = pd.DataFrame(set_list(total))
        obj.columns = (name1, name2)
        sublist = set_list(total)

        if name1 == name2:
            aa = aa[aa[name1].isin(obj[name1].iloc[:, 0])]
            bb = bb[bb[name2].isin(obj[name2].iloc[:, 1])]
        else:
            aa = aa[aa[name1].isin(obj[name1].iloc[:, 0])]
            bb = bb[bb[name2].isin(obj[name2].iloc[:, 1])]

import ipdb;ipdb.set_trace()
